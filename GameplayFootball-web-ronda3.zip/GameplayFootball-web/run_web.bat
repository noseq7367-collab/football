@echo off
setlocal
rem Uso: run_web.bat C:\emsdk
if "%~1"=="" (
  echo Uso: run_web.bat ^<carpeta-de-emsdk^>   por ejemplo: run_web.bat C:\emsdk
  exit /b 1
)
call "%~1\emsdk_env.bat"
if errorlevel 1 exit /b 1

cd /d "%~dp0"
echo Abri Chrome en  http://localhost:8080/gameplayfootball.html   (Ctrl+C para parar el servidor)
python webport\serve.py build_web
