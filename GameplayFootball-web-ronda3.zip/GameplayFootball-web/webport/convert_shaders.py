#!/usr/bin/env python3
"""Convierte los shaders GLSL 150 de Gameplay Football a GLSL ES 3.00 (WebGL2).

Uso: python3 -I convert_shaders.py <dir_origen> <dir_destino>
Transformaciones mecanicas; lo que falte lo reporta el validador en Chromium.
"""
import os
import re
import sys

src, dst = sys.argv[1], sys.argv[2]
os.makedirs(dst, exist_ok=True)

PRECISION = (
    "precision highp float;\n"
    "precision highp int;\n"
    "precision highp sampler2D;\n"
    "precision highp sampler2DShadow;\n"
    "precision highp sampler3D;\n"
)

for name in sorted(os.listdir(src)):
    path = os.path.join(src, name)
    if not (name.endswith(".vert") or name.endswith(".frag")):
        # texturas (noise.png, etc.): copiar tal cual
        with open(path, "rb") as f, open(os.path.join(dst, name), "wb") as g:
            g.write(f.read())
        continue

    with open(path, encoding="utf-8", errors="replace") as f:
        text = f.read()

    is_frag = name.endswith(".frag")

    # 1) #version: en ES tiene que ser lo primero (solo comentarios/espacios antes).
    #    Sacamos la linea vieja y ponemos la nueva arriba de todo, despues el copyright.
    text = re.sub(r"^[ \t]*#version[ \t]+150[^\n]*\n", "", text, flags=re.M)
    header = "#version 300 es\n" + PRECISION

    # 2) texture2D -> texture (ES 3.00 no tiene texture2D)
    text = re.sub(r"\btexture2D\s*\(", "texture(", text)
    text = re.sub(r"\bshadow2D\s*\(", "texture(", text)

    # 3) salidas del fragment shader: layout(location=N) en vez de glBindFragDataLocation
    if is_frag:
        def fix_out(m):
            n = m.group(2)
            loc = int(n) if n else 0
            return f"layout(location = {loc}) out {m.group(1)} stdout{n};"

        text = re.sub(r"^[ \t]*out[ \t]+(vec4)[ \t]+stdout(\d*)[ \t]*;", fix_out, text, flags=re.M)

    # 4) ES 3.00 no hace conversion implicita int->float: literales enteros mezclados con floats
    text = text.replace("* 2 - 1", "* 2.0 - 1.0")
    text = re.sub(r"(\(base\.r \+ base\.g \+ base\.b\)) / 3\)", r"\1 / 3.0)", text)
    text = re.sub(r"\bvec2\(0, 1 / contextHeight\)", "vec2(0.0, 1.0 / contextHeight)", text)
    text = re.sub(r"\bvec2\(1 / contextWidth, 0\)", "vec2(1.0 / contextWidth, 0.0)", text)
    text = re.sub(r"\bvec2\(0, -1 / contextHeight\)", "vec2(0.0, -1.0 / contextHeight)", text)
    text = re.sub(r"\bvec2\(-1 / contextWidth, 0\)", "vec2(-1.0 / contextWidth, 0.0)", text)
    text = re.sub(r"\(1\.0f / poisson_size\)", "(1.0f / float(poisson_size))", text)

    text = text.replace("SSAO /= SSAO_kernelSize * 1.0f;", "SSAO /= float(SSAO_kernelSize);")

    # 5) 'sample' es palabra reservada en GLSL ES 3.00
    text = re.sub(r"\bsample\b", "samplePos", text)

    with open(os.path.join(dst, name), "w", encoding="utf-8") as g:
        g.write(header + text)

print("ok ->", dst)
