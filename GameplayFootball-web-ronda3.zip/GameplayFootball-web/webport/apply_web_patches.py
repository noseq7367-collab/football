#!/usr/bin/env python3
"""Genera la copia WebAssembly de Gameplay Football a partir del codigo ORIGINAL.

Uso:  python3 -I apply_web_patches.py <proyecto_original> <carpeta_salida>

Siempre parte del original y regenera la salida desde cero, asi los parches son reproducibles
y se pueden corregir en este script sin arrastrar ediciones a mano.
Cada parche verifica que el texto buscado exista (si el codigo cambia, falla fuerte).
"""
import os
import re
import shutil
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
SRC, OUT = os.path.abspath(sys.argv[1]), os.path.abspath(sys.argv[2])

if os.path.exists(OUT):
    shutil.rmtree(OUT)
shutil.copytree(SRC, OUT, ignore=shutil.ignore_patterns("build", ".git"))
os.makedirs(os.path.join(OUT, "build"), exist_ok=True)


def read(p):
    with open(p, encoding="utf-8", errors="surrogateescape", newline="") as f:
        return f.read()


def write(p, t):
    with open(p, "w", encoding="utf-8", errors="surrogateescape", newline="") as f:
        f.write(t)


def replace_once(path, old, new, count=1):
    t = read(path)
    n = t.count(old)
    assert n == count, f"{path}: esperaba {count} ocurrencia(s) de {old!r}, hay {n}"
    write(path, t.replace(old, new))


def regex_sub(path, pattern, repl, count_min=1, flags=0):
    t = read(path)
    t2, n = re.subn(pattern, repl, t, flags=flags)
    assert n >= count_min, f"{path}: el patron {pattern!r} coincidio {n} veces (minimo {count_min})"
    write(path, t2)
    return n


# ------------------------------------------------------------------------------------------
# 1) Shaders -> GLSL ES 3.00 (validados aparte en WebGL2 real con validate_shaders.js)
# ------------------------------------------------------------------------------------------
shader_dir = os.path.join(OUT, "data", "media", "shaders")
subprocess.check_call(
    [sys.executable, "-I", os.path.join(HERE, "convert_shaders.py"),
     os.path.join(SRC, "data", "media", "shaders"), shader_dir])

# ------------------------------------------------------------------------------------------
# 2) Hilos / mutex / tiempos: boost (compilado) -> shim sobre std (namespace bc)
#    Filesystem: boost::filesystem -> std::filesystem
# ------------------------------------------------------------------------------------------
os.makedirs(os.path.join(OUT, "src", "webcompat"), exist_ok=True)
shutil.copy(os.path.join(HERE, "webcompat", "thread_compat.hpp"),
            os.path.join(OUT, "src", "webcompat", "thread_compat.hpp"))

stats = {"files": 0}
for root, _, files in os.walk(os.path.join(OUT, "src")):
    if os.sep + "webcompat" in root:
        continue
    for name in files:
        if not name.endswith((".cpp", ".hpp", ".h", ".c")):
            continue
        p = os.path.join(root, name)
        t = read(p)
        o = t

        # includes
        t = re.sub(r'[<"]boost/thread(?:/(?:mutex|condition))?\.hpp[>"]',
                   '"webcompat/thread_compat.hpp"', t)
        t = re.sub(r'[<"]boost/filesystem\.hpp[>"]', "<filesystem>", t)

        # tipos de hilos y tiempo
        t = re.sub(r"\bboost::timed_mutex\b", "bc::timed_mutex", t)
        t = re.sub(r"\bboost::mutex\b", "bc::mutex", t)
        t = re.sub(r"\bboost::condition\b", "bc::condition", t)
        t = re.sub(r"\bboost::thread\b", "bc::thread", t)
        t = re.sub(r"\bboost::this_thread\b", "bc::this_thread", t)
        t = re.sub(r"\bboost::get_system_time\b", "bc::get_system_time", t)
        t = re.sub(r"\bboost::system_time\b", "bc::system_time", t)
        t = re.sub(r"\bboost::posix_time\b", "bc::posix_time", t)
        # std::thread no reconoce boost::reference_wrapper
        t = re.sub(r"bc::thread\(boost::ref\(", "bc::thread(std::ref(", t)

        # filesystem
        t = re.sub(r"\bboost::filesystem\b", "std::filesystem", t)
        t = re.sub(r"\bboost::system::error_code\b", "std::error_code", t)
        t = re.sub(r"\bfs::system_complete\(", "fs::absolute(", t)

        if t != o:
            write(p, t)
            stats["files"] += 1

print("archivos de src modificados (hilos/filesystem):", stats["files"])

# Verificacion: no debe quedar nada de Boost compilado
leftover = []
pat = re.compile(r"boost::(thread|mutex|condition|timed_mutex|filesystem|system::|posix_time|"
                 r"this_thread|system_time|get_system_time)|boost/(thread|filesystem)")
for root, _, files in os.walk(os.path.join(OUT, "src")):
    if os.sep + "webcompat" in root:
        continue
    for name in files:
        if name.endswith((".cpp", ".hpp", ".h", ".c")):
            p = os.path.join(root, name)
            for i, line in enumerate(read(p).splitlines(), 1):
                if pat.search(line):
                    leftover.append(f"{os.path.relpath(p, OUT)}:{i}: {line.strip()}")
assert not leftover, "quedo Boost compilado:\n" + "\n".join(leftover)

# ------------------------------------------------------------------------------------------
# 3) Renderer OpenGL -> WebGL2
# ------------------------------------------------------------------------------------------
R = os.path.join(OUT, "src", "systems", "graphics", "rendering", "opengl_renderer3d.cpp")

# 3a) stubs tipados para las funciones de GL de escritorio que WebGL2 no tiene, y macros de formato
replace_once(R, "  GLfunctions mapping;\n", r'''  GLfunctions mapping;

#ifdef __EMSCRIPTEN__
  // WebGL2 (GLES 3.0) no tiene varias funciones de OpenGL de escritorio (glBegin, glPolygonMode,
  // glBindFragDataLocation, ...). Las que falten se reemplazan por no-ops con la firma EXACTA
  // (en WebAssembly una llamada indirecta con otra firma es un trap).
#define SDL_PROC(ret,func,params) static ret APIENTRY web_stub_##func params { return (ret)0; }
#include "sdl_glfuncs.h"
#undef SDL_PROC
#define WEB_MISSING_GL_FUNC(func) mapping.func = web_stub_##func;

  // Formatos que no existen en GLES3 -> equivalentes
#define GF_GL_RGB16 GL_RGB16F
#define GF_GL_RGBA16 GL_RGBA16F
#define GF_GL_DEPTH32 GL_DEPTH_COMPONENT32F
#define GF_GL_DEPTH_GENERIC GL_DEPTH_COMPONENT24
#else
#define WEB_MISSING_GL_FUNC(func) exit(1);
#define GF_GL_RGB16 GL_RGB16
#define GF_GL_RGBA16 GL_RGBA16
#define GF_GL_DEPTH32 GL_DEPTH_COMPONENT32
#define GF_GL_DEPTH_GENERIC GL_DEPTH_COMPONENT
#endif
''')

# 3b) el cargador de funciones: en vez de exit(1) cuando falta una, usar el stub
regex_sub(R, r"^(\s*)exit\(1\);(\s*\\)$", r"\1WEB_MISSING_GL_FUNC(func)\2", count_min=1, flags=re.M)

# 3c) pedir un contexto WebGL2 (GLES 3.0) antes de crear la ventana
replace_once(R, '    window = SDL_CreateWindow("Gameplay Football", SDL_WINDOWPOS_UNDEFINED,',
             '''#ifdef __EMSCRIPTEN__
    SDL_GL_SetAttribute(SDL_GL_CONTEXT_MAJOR_VERSION, 3);
    SDL_GL_SetAttribute(SDL_GL_CONTEXT_MINOR_VERSION, 0);
    SDL_GL_SetAttribute(SDL_GL_CONTEXT_PROFILE_MASK, SDL_GL_CONTEXT_PROFILE_ES);
#endif
    window = SDL_CreateWindow("Gameplay Football", SDL_WINDOWPOS_UNDEFINED,''')

# 3d) GL_MULTISAMPLE no existe en GLES3
regex_sub(R, r"^(\s*)mapping\.glDisable\(GL_MULTISAMPLE\);",
          "#ifndef __EMSCRIPTEN__\n\\1mapping.glDisable(GL_MULTISAMPLE);\n#endif", count_min=1, flags=re.M)

# 3e) formatos internos sin equivalente directo
regex_sub(R, r"(e_InternalPixelFormat_RGB16:\s+format = )GL_RGB16(; break;)", r"\1GF_GL_RGB16\2")
regex_sub(R, r"(e_InternalPixelFormat_RGBA16:\s+format = )GL_RGBA16(; break;)", r"\1GF_GL_RGBA16\2")
regex_sub(R, r"(e_InternalPixelFormat_DepthComponent32:\s+format = )GL_DEPTH_COMPONENT32(; break;)",
          r"\1GF_GL_DEPTH32\2")
regex_sub(R, r"(e_InternalPixelFormat_DepthComponent:\s+format = )GL_DEPTH_COMPONENT(; break;)",
          r"\1GF_GL_DEPTH_GENERIC\2")

# 3f) WebGL2 exige que (formato interno, formato, tipo) sea una combinacion valida; el original
#     usaba siempre GL_UNSIGNED_BYTE (tolerado por GL de escritorio, error en WebGL2).
replace_once(R, "  int OpenGLRenderer3D::CreateTexture(e_InternalPixelFormat internalPixelFormat,",
             r'''  // Tipo de dato valido para cada formato interno (requisito de WebGL2).
  GLenum GetGLPixelType(e_InternalPixelFormat pixelFormat) {
#ifdef __EMSCRIPTEN__
    switch (pixelFormat) {
      case e_InternalPixelFormat_RGB16:
      case e_InternalPixelFormat_RGBA16:
      case e_InternalPixelFormat_RGBA16F:           return GL_HALF_FLOAT;
      case e_InternalPixelFormat_RGBA32F:           return GL_FLOAT;
      case e_InternalPixelFormat_DepthComponent16:  return GL_UNSIGNED_SHORT;
      case e_InternalPixelFormat_DepthComponent:
      case e_InternalPixelFormat_DepthComponent24:  return GL_UNSIGNED_INT;
      case e_InternalPixelFormat_DepthComponent32:
      case e_InternalPixelFormat_DepthComponent32F: return GL_FLOAT;
      default:                                      return GL_UNSIGNED_BYTE;
    }
#else
    (void)pixelFormat;
    return GL_UNSIGNED_BYTE;
#endif
  }

  int OpenGLRenderer3D::CreateTexture(e_InternalPixelFormat internalPixelFormat,''')
replace_once(R, "GetGLPixelFormat(pixelFormat), GL_UNSIGNED_BYTE, NULL);",
             "GetGLPixelFormat(pixelFormat), GetGLPixelType(internalPixelFormat), NULL);")

# ------------------------------------------------------------------------------------------
# 4) CMake para Emscripten (se genera a partir del original)
# ------------------------------------------------------------------------------------------
cm = read(os.path.join(SRC, "CMakeLists.txt"))
i_find = cm.index("# Find required libraries")
i_inc = cm.index("# Include the sources")
i_libs = cm.index("set(LIBRARIES")

head = cm[:i_find]
head = head.replace("cmake_minimum_required(VERSION 3.1)", "cmake_minimum_required(VERSION 3.13)")
head = head.replace("set (CMAKE_CXX_STANDARD 14)", "set (CMAKE_CXX_STANDARD 17)")
middle = cm[i_inc:i_libs]

web_head = r'''# ---- Port WebAssembly (Emscripten) ----------------------------------------------------------
# Generado por webport/apply_web_patches.py. Usar:  emcmake cmake .. -G Ninja
if(NOT EMSCRIPTEN)
  message(FATAL_ERROR "Este CMakeLists es del port web: configurar con 'emcmake cmake ..'")
endif()

# Librerias que Emscripten trae como "ports" (se bajan solas de GitHub la primera vez)
set(GF_PORTS
    --use-port=sdl2
    --use-port=sdl2_image:formats=png,jpg
    --use-port=sdl2_ttf
    --use-port=sdl2_gfx
    --use-port=boost_headers   # solo headers: intrusive_ptr, bind, signals2, circular_buffer, random...
    --use-port=sqlite3)
add_compile_options(${GF_PORTS} -pthread -fexceptions)

include_directories(${PROJECT_SOURCE_DIR}/src)

'''

web_tail = r'''set(LIBRARIES gamelib hidlib menulib datalib leaguelib blunted2 openal)

add_executable(gameplayfootball ${CORE_SOURCES} ${CORE_HEADERS})
target_link_libraries(gameplayfootball ${LIBRARIES})

target_link_options(gameplayfootball PRIVATE
    ${GF_PORTS} -pthread -fexceptions
    # El motor es multihilo y tiene loops bloqueantes: main() corre en un worker, no en el hilo de la pagina
    -sPROXY_TO_PTHREAD=1
    -sPTHREAD_POOL_SIZE=24
    -sOFFSCREENCANVAS_SUPPORT=1
    -sOFFSCREEN_FRAMEBUFFER=1
    # WebGL2 / GLES 3.0
    -sMIN_WEBGL_VERSION=2
    -sMAX_WEBGL_VERSION=2
    -sFULL_ES3=1
    -sGL_ENABLE_GET_PROC_ADDRESS=1
    # Memoria y pilas
    -sALLOW_MEMORY_GROWTH=1
    -sINITIAL_MEMORY=268435456
    -sMAXIMUM_MEMORY=2147483648
    -sSTACK_SIZE=5242880
    -sDEFAULT_PTHREAD_STACK_SIZE=2097152
    -sASSERTIONS=1
    -sEXIT_RUNTIME=1
    # Assets (media/, databases/, football.config) disponibles como "/" en el filesystem virtual
    --preload-file ${PROJECT_SOURCE_DIR}/data@/)

set_target_properties(gameplayfootball PROPERTIES SUFFIX ".html")
'''
write(os.path.join(OUT, "CMakeLists.txt"), head + web_head + middle + web_tail)

# ------------------------------------------------------------------------------------------
# 5) Herramientas y guia
# ------------------------------------------------------------------------------------------
wp = os.path.join(OUT, "webport")
os.makedirs(wp, exist_ok=True)
for f in ("convert_shaders.py", "validate_shaders.js", "apply_web_patches.py"):
    shutil.copy(os.path.join(HERE, f), os.path.join(wp, f))
for f in ("build_web.bat", "run_web.bat", "serve.py", "LEEME_WINDOWS.md"):
    shutil.copy(os.path.join(HERE, f), os.path.join(OUT if f.endswith(".bat") else wp, f))

print("OK ->", OUT)
