# Estado del port (ronda 2)

Cambios de esta ronda (hechos SIN compilar: no hay Emscripten en mi entorno):
- `src/types/refcounted.hpp`: se saca `boost/detail/atomic_count.hpp` (no se usaba y puede no existir
  en Boost nuevo) y se incluye el shim de hilos explicitamente (usa `bc::mutex`).
- `opengl_renderer3d.cpp`: tokens GLES3 (`GL_RGBA16F`, `GL_HALF_FLOAT`, ...) definidos si el `gl.h`
  de Emscripten no los trae; `emscripten_webgl_commit_frame()` tras cada `SDL_GL_SwapWindow`.
- `CMakeLists.txt`: pool de hilos = nucleos + 14, y puede crecer (`PTHREAD_POOL_SIZE_STRICT=0`).
- Nota: estos cambios estan hechos directo sobre este arbol; `apply_web_patches.py` ya no los regenera.

Riesgos que solo se ven al compilar/ejecutar:
1. Errores de compilacion (headers de GL/SDL/Boost). Pegar `findstr /C:"error:" build_log.txt`.
2. Pantalla negra: contexto WebGL2 creado por SDL en un hilo (no en el principal). Mirar F12 > Console.
3. Teclado sin respuesta: eventos SDL se leen en el hilo del renderer.
4. Audio: el navegador solo lo activa tras un click/tecla.

## Publicar en la web (sin PowerShell)
Subir el proyecto a GitHub (rama main) y activar Settings > Pages > Source: GitHub Actions.
`.github/workflows/deploy.yml` compila con Emscripten y publica; `webport/coi-serviceworker.js` reemplaza a serve.py.
