# Gameplay Football en el navegador (WebAssembly) - guía para Windows

Este es un port **sin probar**: se escribió sin poder compilarlo. Lo esperable es que el
compilador tire errores la primera vez. La idea es que me pases esos errores y los voy
corrigiendo en rondas.

## 1. Instalar herramientas (una sola vez)

Abrí PowerShell y corré:

```powershell
winget install Git.Git
winget install Kitware.CMake
winget install Ninja-build.Ninja
```

Cerrá y volvé a abrir PowerShell para que tome los programas nuevos.

## 2. Instalar Emscripten (una sola vez)

```powershell
git clone https://github.com/emscripten-core/emsdk.git C:\emsdk
cd C:\emsdk
.\emsdk install latest
.\emsdk activate latest
```

Emscripten trae su propio Python y Node, no hace falta instalarlos.

## 3. Compilar

Descomprimí este proyecto en una carpeta **sin espacios ni acentos** (por ejemplo `C:\gf_web`) y:

```powershell
cd C:\gf_web
.\build_web.bat C:\emsdk
```

- La primera vez baja solo SDL2, SQLite, Boost (headers) y otras librerías desde GitHub. Necesita internet y tarda.
- Si falla, el detalle queda en `build_log.txt`. Para ver solo los errores:
  `findstr /C:"error:" build_log.txt`
- **Pasame los errores** (pegalos tal cual, con el nombre de archivo y línea).

## 4. Probar

```powershell
.\run_web.bat C:\emsdk
```

Abrí **Chrome** en http://localhost:8080/gameplayfootball.html

Tiene que ser con este servidor y no abriendo el `.html` con doble clic: los hilos del juego
necesitan unos headers especiales (COOP/COEP) que `serve.py` agrega.

Si la pantalla queda negra o no arranca, apretá F12, andá a la pestaña "Console" y pasame lo que diga.

## Qué se cambió respecto al original

- **Shaders**: pasados a GLSL ES 3.00 (WebGL2). Los 6 programas se validaron compilando y linkeando en un WebGL2 real.
- **Boost compilado** (`thread`, `filesystem`): reemplazado por la librería estándar (`src/webcompat/thread_compat.hpp`).
- **Renderer**: funciones de OpenGL de escritorio que WebGL2 no tiene se reemplazan por no-ops; formatos de textura y tipos de dato ajustados a lo que exige WebGL2.
- **CMake**: configuración para Emscripten (hilos con `-pthread`, `main()` en un worker, WebGL2, assets empaquetados).

Todo se regenera desde el código original con `webport/apply_web_patches.py`.
