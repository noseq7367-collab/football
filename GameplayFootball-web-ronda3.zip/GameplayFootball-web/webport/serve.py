#!/usr/bin/env python3
"""Servidor estatico para el build web.

Los hilos en el navegador (SharedArrayBuffer) solo funcionan si la pagina se sirve con los
headers COOP/COEP. Este servidor los agrega; el servidor "python -m http.server" comun no.

Uso: python serve.py <carpeta_del_build> [puerto]
"""
import http.server
import os
import socketserver
import sys

folder = sys.argv[1] if len(sys.argv) > 1 else "."
port = int(sys.argv[2]) if len(sys.argv) > 2 else 8080


class Handler(http.server.SimpleHTTPRequestHandler):
    extensions_map = {
        **http.server.SimpleHTTPRequestHandler.extensions_map,
        ".wasm": "application/wasm",
        ".js": "text/javascript",
        ".data": "application/octet-stream",
    }

    def end_headers(self):
        self.send_header("Cross-Origin-Opener-Policy", "same-origin")
        self.send_header("Cross-Origin-Embedder-Policy", "require-corp")
        self.send_header("Cache-Control", "no-store")
        super().end_headers()


os.chdir(folder)
socketserver.ThreadingTCPServer.allow_reuse_address = True
with socketserver.ThreadingTCPServer(("", port), Handler) as httpd:
    print(f"Sirviendo {os.getcwd()} en http://localhost:{port}/gameplayfootball.html")
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        pass
