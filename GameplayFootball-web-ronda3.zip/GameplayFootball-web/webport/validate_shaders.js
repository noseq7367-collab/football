// Compila y linkea cada par de shaders en WebGL2 real (Chromium headless).
// Uso: node validate_shaders.js <dir_shaders>
const path = require('path');
const fs = require('fs');
const { chromium } = require('/opt/node22/lib/node_modules/playwright');

const dir = process.argv[2];

// Mismos bindAttribLocation que hace LoadShader() en opengl_renderer3d.cpp
const ATTRS = {
  zphase: { position: 0 },
  simple: { position: 0, normal: 1, texcoord: 2, tangent: 3, bitangent: 4 },
  ambient: { position: 0 },
  lighting: {},
  postprocess: { position: 0 },
  overlay: { vertex: 0 },
};

(async () => {
  const shaders = {};
  for (const name of Object.keys(ATTRS)) {
    shaders[name] = {
      vert: fs.readFileSync(path.join(dir, name + '.vert'), 'utf8'),
      frag: fs.readFileSync(path.join(dir, name + '.frag'), 'utf8'),
      attrs: ATTRS[name],
    };
  }

  const browser = await chromium.launch({
    args: ['--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'],
  });
  const page = await browser.newPage();
  const result = await page.evaluate((shaders) => {
    const c = document.createElement('canvas');
    const gl = c.getContext('webgl2');
    if (!gl) return { fatal: 'no hay WebGL2' };
    const out = { version: gl.getParameter(gl.VERSION), glsl: gl.getParameter(gl.SHADING_LANGUAGE_VERSION), maxDrawBuffers: gl.getParameter(gl.MAX_DRAW_BUFFERS), programs: {} };
    for (const [name, s] of Object.entries(shaders)) {
      const r = { vert: 'ok', frag: 'ok', link: 'ok' };
      const mk = (type, src) => {
        const sh = gl.createShader(type);
        gl.shaderSource(sh, src);
        gl.compileShader(sh);
        return { sh, ok: gl.getShaderParameter(sh, gl.COMPILE_STATUS), log: gl.getShaderInfoLog(sh) };
      };
      const v = mk(gl.VERTEX_SHADER, s.vert);
      const f = mk(gl.FRAGMENT_SHADER, s.frag);
      if (!v.ok) r.vert = v.log;
      if (!f.ok) r.frag = f.log;
      if (v.ok && f.ok) {
        const p = gl.createProgram();
        gl.attachShader(p, v.sh);
        gl.attachShader(p, f.sh);
        for (const [a, i] of Object.entries(s.attrs)) gl.bindAttribLocation(p, i, a);
        gl.linkProgram(p);
        if (!gl.getProgramParameter(p, gl.LINK_STATUS)) r.link = gl.getProgramInfoLog(p);
      } else {
        r.link = 'saltado';
      }
      out.programs[name] = r;
    }
    return out;
  }, shaders);
  await browser.close();

  if (result.fatal) { console.log('FATAL:', result.fatal); process.exit(2); }
  console.log(result.version, '|', result.glsl, '| MAX_DRAW_BUFFERS =', result.maxDrawBuffers);
  let bad = 0;
  for (const [n, r] of Object.entries(result.programs)) {
    const ok = r.vert === 'ok' && r.frag === 'ok' && r.link === 'ok';
    if (!ok) bad++;
    console.log((ok ? 'OK   ' : 'FALLA'), n);
    if (r.vert !== 'ok') console.log('   [vert]', r.vert.trim().split('\n').slice(0, 8).join('\n          '));
    if (r.frag !== 'ok') console.log('   [frag]', r.frag.trim().split('\n').slice(0, 12).join('\n          '));
    if (r.link !== 'ok' && r.link !== 'saltado') console.log('   [link]', r.link.trim());
  }
  process.exit(bad ? 1 : 0);
})();
