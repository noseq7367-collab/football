/* Agrega los headers COOP/COEP desde el navegador, para que los hilos (SharedArrayBuffer)
   funcionen en hostings que no dejan configurar headers (GitHub Pages, etc). */
if (typeof window === "undefined") {
  // ---- corre como Service Worker ----
  self.addEventListener("install", () => self.skipWaiting());
  self.addEventListener("activate", (e) => e.waitUntil(self.clients.claim()));
  self.addEventListener("fetch", (e) => {
    const r = e.request;
    if (r.cache === "only-if-cached" && r.mode !== "same-origin") return;
    e.respondWith(
      fetch(r)
        .then((res) => {
          if (res.status === 0) return res;
          const h = new Headers(res.headers);
          h.set("Cross-Origin-Embedder-Policy", "require-corp");
          h.set("Cross-Origin-Opener-Policy", "same-origin");
          return new Response(res.body, { status: res.status, statusText: res.statusText, headers: h });
        })
        .catch((err) => console.error(err))
    );
  });
} else {
  // ---- corre como script de la pagina ----
  (function () {
    const self_src = document.currentScript && document.currentScript.src;
    if (window.crossOriginIsolated) return;
    if (!window.isSecureContext || !("serviceWorker" in navigator)) {
      console.warn("Sin contexto seguro / service workers: el juego no va a poder usar hilos.");
      return;
    }
    navigator.serviceWorker.register(self_src).then(
      (reg) => {
        reg.addEventListener("updatefound", () => window.location.reload());
        if (reg.active && !navigator.serviceWorker.controller) window.location.reload();
      },
      (err) => console.error("No se pudo registrar el service worker:", err)
    );
  })();
}
