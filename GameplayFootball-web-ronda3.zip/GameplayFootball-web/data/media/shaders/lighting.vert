#version 300 es
precision highp float;
precision highp int;
precision highp sampler2D;
precision highp sampler2DShadow;
precision highp sampler3D;

#pragma optimize(on)

uniform mat4 modelMatrix;
uniform mat4 viewMatrix;
uniform mat4 projectionMatrix;

// eye-space
in vec4 position;

out mat4 modelViewMatrix;
out vec4 modelViewPosition;

void main(void) {
  modelViewMatrix = viewMatrix * modelMatrix;
  modelViewPosition = modelViewMatrix * position;
  gl_Position = projectionMatrix * modelViewPosition;
}
