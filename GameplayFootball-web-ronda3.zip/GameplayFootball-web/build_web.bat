@echo off
setlocal
rem Uso: build_web.bat C:\emsdk     (la carpeta donde instalaste emsdk)
if "%~1"=="" (
  echo Uso: build_web.bat ^<carpeta-de-emsdk^>   por ejemplo: build_web.bat C:\emsdk
  exit /b 1
)
call "%~1\emsdk_env.bat"
if errorlevel 1 exit /b 1

cd /d "%~dp0"
if not exist build_web mkdir build_web
cd build_web

call emcmake cmake .. -G Ninja -DCMAKE_BUILD_TYPE=Release
if errorlevel 1 (
  echo.
  echo FALLO la configuracion de CMake. Copia el mensaje de arriba.
  exit /b 1
)

rem -k 0 = no frenar en el primer error: junta TODOS los errores en una sola pasada
cmake --build . -- -k 0 > ..\build_log.txt 2>&1
if errorlevel 1 (
  echo.
  echo FALLO la compilacion. El detalle esta en build_log.txt
  echo Para ver solo los errores:  findstr /C:"error:" build_log.txt
  exit /b 1
)

echo.
echo LISTO. Ahora corre: run_web.bat %~1
