// Reemplazo minimo de boost::thread / boost::mutex / boost::condition / boost::posix_time
// sobre la libreria estandar, para el port a WebAssembly.
//
// Por que existe: Emscripten no trae las librerias *compiladas* de Boost (thread, filesystem),
// solo los headers. Este archivo cubre exactamente lo que usa Gameplay Football, nada mas.
// Todo vive en el namespace "bc" (boost compat) para no chocar con los headers reales de Boost
// que si estan disponibles (bind, signals2, intrusive_ptr, circular_buffer, ...).

#ifndef GF_WEBCOMPAT_THREAD_COMPAT_HPP
#define GF_WEBCOMPAT_THREAD_COMPAT_HPP

#include <chrono>
#include <condition_variable>
#include <functional>
#include <mutex>
#include <thread>
#include <type_traits>
#include <utility>

namespace bc {

// ---- tiempo ---------------------------------------------------------------------------------

namespace posix_time {

struct time_duration {
  std::chrono::microseconds us{0};
  long long total_milliseconds() const {
    return std::chrono::duration_cast<std::chrono::milliseconds>(us).count();
  }
  long long total_microseconds() const { return us.count(); }
};

inline time_duration milliseconds(long long n) {
  return time_duration{std::chrono::milliseconds(n)};
}
inline time_duration microseconds(long long n) {
  return time_duration{std::chrono::microseconds(n)};
}

struct ptime {
  std::chrono::system_clock::time_point tp;
};

inline time_duration operator-(const ptime &a, const ptime &b) {
  return time_duration{std::chrono::duration_cast<std::chrono::microseconds>(a.tp - b.tp)};
}

struct microsec_clock {
  static ptime local_time() { return ptime{std::chrono::system_clock::now()}; }
};

// system_time + duration. Se define aca (y no en bc::) para que ADL lo encuentre
// a traves del argumento time_duration.
inline std::chrono::system_clock::time_point operator+(
    const std::chrono::system_clock::time_point &t, const time_duration &d) {
  return t + std::chrono::duration_cast<std::chrono::system_clock::duration>(d.us);
}

}  // namespace posix_time

typedef std::chrono::system_clock::time_point system_time;

inline system_time get_system_time() { return std::chrono::system_clock::now(); }

// ---- mutex ----------------------------------------------------------------------------------

class mutex : public std::mutex {
 public:
  typedef std::unique_lock<std::mutex> scoped_lock;
};

class timed_mutex : public std::timed_mutex {
 public:
  typedef std::unique_lock<std::timed_mutex> scoped_lock;
};

// ---- condition ------------------------------------------------------------------------------

class condition {
 public:
  template <class Lock>
  void wait(Lock &lock) {
    cv_.wait(lock);
  }

  // Igual que boost: devuelve false si vencio el timeout, true si lo desperto una notificacion.
  template <class Lock>
  bool timed_wait(Lock &lock, const system_time &absolute) {
    return cv_.wait_until(lock, absolute) == std::cv_status::no_timeout;
  }

  void notify_one() { cv_.notify_one(); }
  void notify_all() { cv_.notify_all(); }

 private:
  std::condition_variable_any cv_;
};

// ---- thread ---------------------------------------------------------------------------------

class thread : public std::thread {
 public:
  thread() noexcept = default;

  template <class F, class... Args,
            class = typename std::enable_if<
                !std::is_same<typename std::decay<F>::type, thread>::value>::type>
  explicit thread(F &&f, Args &&...args)
      : std::thread(std::forward<F>(f), std::forward<Args>(args)...) {}

  thread(thread &&) noexcept = default;
  thread &operator=(thread &&) noexcept = default;

  static unsigned hardware_concurrency() noexcept { return std::thread::hardware_concurrency(); }
};

namespace this_thread {

inline void yield() { std::this_thread::yield(); }

inline void sleep(const posix_time::time_duration &d) { std::this_thread::sleep_for(d.us); }

}  // namespace this_thread

}  // namespace bc

#endif  // GF_WEBCOMPAT_THREAD_COMPAT_HPP
